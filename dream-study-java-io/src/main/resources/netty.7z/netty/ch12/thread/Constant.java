package com.imooc.netty.ch12.thread;

/**
 * @author 闪电侠
 */
public class Constant {
    public static final int PORT = 8000;
}
